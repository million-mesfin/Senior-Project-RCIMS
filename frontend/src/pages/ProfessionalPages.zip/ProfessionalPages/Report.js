import React from "react";
const Report = () => {  

    return (
        <div>
            <h1>Report</h1>
            <p>This is the report page.</p>
        </div>
    );
};

export default Report;
            
    
