import React, { useState } from "react"; 



  
    <div>
      <h1>this page is for predection</h1>

     
      </div>
   
export default Predictions;
